var a = 3;
var b = 4;
var c = 6;
var r = a + b;
console.log(r);


// Declaración de una función
function sumar() {
    // let result = a + c;
    // console.log(`La suma de a + c es: ${result}`);
    document.getElementById("resultado").innerHTML = `La suma de a + c es: ${a + c}`;
}

console.log(a * b);

// Invocación de una función, llamar a la función
sumar();
console.log(a - c);
sumar();

// la reutilizo para calcular el sueldo de 100 empleados
function calcularSueldo () {
// sumar restas consultas
}

function restar() {
    document.getElementById("resultado").innerHTML = `La resta de a - c es: ${a - c}`;
}

function maximo() {
    let mensaje = `El máximo entre ${a} y ${b} es: ${Math.max(a, b)}`;
    document.getElementById("resultado").innerHTML = mensaje;
}

var nombre = "Pedro ";
var apellido = "Suarez";
function concatenar() {
    document.getElementById("resultado").innerHTML = `La concatenación del Nombre y Apellido es: ${nombre + apellido}`
}

function mayor() {
    document.getElementById("resultado").innerHTML = `${a} > ${b}: ${a > b}`;
}

const edadMayor = 18;
function esMayorEdad() {
    // obtiene la edad que ingresó el usuario
    let edadUsuario = document.getElementById("edadUsu").value;
    
    // compara la edad y genera el mensaje
    let mensaje = `<b>El usuario es mayor de edad?</b> ${edadUsuario >= edadMayor}`;
    
    // inyecta html a la página con el resultado
    document.getElementById("resultado").innerHTML = mensaje;
 
}

var usu = "juan@gmail.com";
var pass = "1234";
function validarUsuario() {
    let nombreUsu = document.getElementById("nombreUsu").value;
    let passUsu = document.getElementById("passUsu").value;

    let mensaje = `El usuario y la contraseña son validos? ${usu == nombreUsu && pass == passUsu}`;

    document.getElementById("resultado").innerHTML = mensaje;
}