var a = 5;
var b = 2;
var c = 10;
var d = 5;
var nombre = "Pedro";
var resultado;
var ok;

var edad1 = 18;
var edad2 = 17;
var mayorEdad = 18;

function sumar() {
    let resultado = a + b;
    console.log("La suma de a + b es: " + resultado);
}

function restar() {
    resultado = a - b;
    console.log("La suma de a - b es: " + resultado);
}

function maximo() {
    resultado = Math.max(a,b)
    console.log("El máximo entre a y b es: " + resultado);
}

function concatenar() {
    resultado = nombre + " Suarez"
    console.log("Nombre y Apellido: " + resultado);
    console.log(`Nombre y Apellido: ${resultado}`);
}

function esMayor() {
    ok = a > b;
    console.log(`${a} > ${b}: ${ok}`);
}

function esMenor() {
    ok = a < b;
    console.log(`${a} < ${b}: ${ok}`);
}

function mayorIgual() {
    ok = a >= d;
    console.log(`${a} >= ${d}: ${ok}`);
}

function esMayorEdad() {
    let edad = document.getElementById('edad').value; 
    ok = edad >= mayorEdad;
    console.log(`${edad} >= ${mayorEdad}: ${ok}`);
    document.getElementById('resultado').innerHTML = `${edad} >= ${mayorEdad}: ${ok}`;

}

function operadorAnd() {
    //ok = true && true;
    //ok = (a > b) && (b > c);
    ok = (a > b) && (c > b);
    console.log(ok);
}

function operadorOr() {
    //ok = false || false; 
    // ok = (a > b) || (b > c);
    ok = (a > b) || (c > b);
    console.log(ok);
}

function operadorNot() {
    ok = !true;
    // ok = (a > b) || (b > c);
    //ok = (a > b) || (c > b);
    console.log(ok);
}

function condicionIf() {
    ok = false;
    if(ok) {
        console.log("If Verdadero");
    } else {
        console.log("If Falso");
    }
}

function esMayorEdadConIf() {
    let edad = document.getElementById('edad').value; 
    if(edad >= mayorEdad) {
        console.log("Puede ingresar");
    } else {
        console.log("No puede ingresar ");
    }
}

function nombreMes() {
    let nroMes = document.getElementById("nroMes").value;
    switch (nroMes) {
        case "1":
            console.log("Enero");
            break;
        case "2":
            console.log("Febrero");
            break;
        case "3":
            console.log("Marzo");
            break;
        case "4":
            console.log("Abril");
            break;
        default:
            console.log("Mes no encontrado");
            break;
    }

}

function bucleFor() {
    for (let i = 0; i < 5; i++) {
        // Se ejecuta 5 veces, con valores del paso 0 al 4.
        console.log('Valor de i:' + i);
      }
}

function bucleWhile() {
    let n = 0;
    let x = 0;
    while (n < 3) {
      n++;
      console.log("n: " + n)
    }    
}

function bucleDo() {
    let i = 0;
    do {
        i += 1;
        console.log(i);
    } while (i < 5);
}