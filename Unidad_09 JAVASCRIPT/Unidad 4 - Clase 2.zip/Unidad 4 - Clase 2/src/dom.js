/** DOM 
 Permite la manipulación de elementos html
 Con DOM JavaScript obtiene todo el poder que necesita para crear HTML dinámico
 * */

/** Métodos y propiedades
   Los métodos HTML DOM son acciones que puede realizar (en elementos HTML).
   Las propiedades HTML DOM son valores (de elementos HTML) que puede establecer o cambiar.
*/
// método getElementByid, propiedad innerHTML
document.getElementById("hola").innerHTML = "Bienvenidos a DOM!";




function crearNota() {
    // modificación contenido html
    document.getElementById("nota").innerHTML = "Bienvenido DOM"

    // modificación de texto de botón
    document.getElementById("btnCrearNota").value = "Eliminar Nota";
    // modificación de evento
    document.getElementById("btnCrearNota").onclick = "eliminarNota();";
}

// modifiación estilo css
function cambiarColorNota() {
    document.getElementById("nota").style.color = "blue";
}

//var x = document.getElementsByTagName("p");
//var x = document.getElementsByClassName("intro");
// var x = document.querySelectorAll("p.intro");
// document.getElementById("p2").style.color = "blue";
// buscar por nombre etiqueta
var listaP = document.getElementsByTagName("p");
console.log(listaP);

// buscar por nombre de clase
var listaClase = document.getElementsByClassName("textoPrincipal");
console.log(listaClase);

//animaciones

/** EVENTOS 
    suceso que ocurre en la ventada del navegador
*/
const btn = document.getElementById('btnEvento');
btn.onclick = function () {
    document.body.style.backgroundColor = "blue";
}

btn.onmouseover = function () {
    document.body.style.backgroundColor = "red";
}


btn.onmouseleave = function () {
    document.body.style.backgroundColor = "green";
}


const p = document.getElementById('mouserOver');
p.onmouseover = logMouseOver;
p.onmouseout = logMouseOut;
function logMouseOver() {
    p.innerHTML = 'MOUSE OVER detected';
    p.style.color = "red";
}

function logMouseOut() {
    p.innerHTML = 'MOUSE OUT detected';
    p.style.color = "blue";
}

// cantidad de imagenes
document.images.length;
document.links.length;
document.links[0].href;
// cantidad de elementos de un tag
var x = document.getElementsByTagName("input");
x.length;

// escribir contenido
document.open();
document.write("<h1>Quita el contenido viejo - Agrega el contenido nuevo!</h1>");
document.close();

document.title;
document.referrer;
document.cookie;
document.URL;
document.getElementById('p1').style.visibility='hidden';
document.getElementById('p1').style.visibility='visible';

window.open("https://www.google.com");

var myWindow;
function openWin() {
  myWindow = window.open("", "", "width=400, height=200");
}

function closeWin() {
  myWindow.close();
}


var myWindow;
function openWin() {
  myWindow = window.open("", "", "width=400, height=200");
  myWindow.blur();
}
function blurWin() {
  myWindow.blur();
}
function focusWin() {
  myWindow.focus();
}


function openWin() {
    var myWindow = window.open("", "", "width=400, height=200");
    myWindow.opener.document.getElementById("demo").innerHTML = 
    "A new window has been opened.";
  }

 var myWindow;
function openWin() {
  myWindow=window.open("", "", "width=400, height=200");
}
function moveWin() {
  myWindow.moveBy(250, 250)
}

window.print();

var w;
function openwindow() {
  w = window.open('','', 'width=100,height=100');
  w.focus();
}

function myFunction() {
  w.resizeTo(500, 500);
  w.focus();
}

function bgChange() {
var rndCol = 'rgb(' + Math.random(255) + ',' + Math.random(255) + ',' + Math.random(255) + ')';
document.body.style.backgroundColor = rndCol;
}