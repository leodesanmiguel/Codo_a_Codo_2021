document.open();
document.write("<h1>Bienvenidos, mensaje dinámico</h1>");
document.close();

var ventana;
function abrirVentana() {
    ventana = window.open("validarCampos.html", "", "width=500, height=300");
}

function cerrarVentana() {
    ventana.close();
}

function ponerFoco() {
    ventana.focus();
}

function sacarFoco() {
    ventana.blur();
}

function mover() {
    ventana.moveBy(100,100);
    ventana.focus();
}

function imprimir() {
    window.print();
}
