// simular que trajimos datos de la base de datos
var listAlumnos = [
    [1, "Pedro", "Suarez", 25666345],
    [2, "Josefa", "Rodriguez", 25666345],
    [3, "Nicanor", "Paredes", 25666345],
    [4, "Jacinto", "Chiclana", 25666345],
    [5, "Santos", "Vega", 25666345],
    [6, "Enrique Santos", "Dicepolo", 25666345],
];

document.open();
document.write("<br>");
for (let i = 0; i < listAlumnos.length; i++) {
    document.write("<div class='cajaAlumno'>");
    document.write(`<p>Nombre y Apellido: ${listAlumnos[i][1]}, ${listAlumnos[i][2]}</p>`);
    document.write(`<p>DNI: ${listAlumnos[i][3]}</p>`);
    document.write("</div>")
    
}
document.close();