function validarMail() {
    let mail = document.getElementById("correo").value; 

    let mailMinusculas = mail.toLowerCase();

    if (mail == "" || mail.indexOf("@") == -1 || mailMinusculas.indexOf("@cursojava.com.ar") == -1) {
        mensajeInvalido("El email es inválido");
    } else {
        mensajeValido("El email es válido");
    }
}

function validar5Char() {
    let cincoChar = document.getElementById("5Char").value;

    if (cincoChar.length < 8) {
        mensajeInvalido("Debe ingresar al menos 8 caractéres.")
    } else {
        mensajeValido("Los caracteres están ok");
    }
}

function mensajeValido(mensaje) {
    document.getElementById("mensajes").innerHTML = mensaje;
    document.getElementById("mensajes").style.backgroundColor = "#4CC8F0";
}

function mensajeInvalido(mensaje) {
    document.getElementById("mensajes").innerHTML = mensaje;
    document.getElementById("mensajes").style.backgroundColor = "#F0564C";
}

function fortalezaPass() {
    let pass = document.getElementById("contrasenia").value; 
    let seguridad;

    if (pass.length >=0 && pass.length <=4) {
        seguridad = "10%";
        color = "red";
    } else if (pass.length > 4 && pass.length <= 7) {
        seguridad = "30%";
        color = "lightblue";
    } else if (pass.length > 7 && pass.length <=10) {
        seguridad = "70%";
        color = "green";
    }

    document.getElementById("fortaleza").innerHTML = seguridad;
    document.getElementById("fortaleza").style.backgroundColor = color;

}